// ==================== DATOS DE PLANTAS COLOMBIANAS ====================
const plantas = {
    ituango: { nombre: "Hidroituango", anio: 2018, capacidad: "2400 MW", ciudades: "Antioquia", importancia: "La más grande de Colombia" },
    guatape: { nombre: "Guatapé", anio: 1979, capacidad: "560 MW", ciudades: "Antioquia", importancia: "Regulación eléctrica" },
    chivor: { nombre: "Chivor", anio: 1982, capacidad: "1000 MW", ciudades: "Cundinamarca", importancia: "Energía central" },
    sancarlos: { nombre: "San Carlos", anio: 1984, capacidad: "1240 MW", ciudades: "Antioquia", importancia: "Clave nacional" },
    betania: { nombre: "Betania", anio: 1987, capacidad: "540 MW", ciudades: "Huila", importancia: "Región sur" },
    porce: { nombre: "Porce III", anio: 2011, capacidad: "660 MW", ciudades: "Antioquia", importancia: "Moderna" }
};

// ==================== FUNCIONES DE NAVEGACIÓN ====================
function showSection(id) {
    const sections = document.querySelectorAll(".tab");
    if (sections.length > 0) {
        sections.forEach(e => e.classList.remove("active"));
    }
    const targetSection = document.getElementById(id);
    if (targetSection) {
        targetSection.classList.add("active");
    }
}

function showPlant(key) {
    const p = plantas[key];
    const plantInfo = document.getElementById("plantInfo");
    if (plantInfo && p) {
        plantInfo.innerHTML = `
            <h4>💧 ${p.nombre}</h4>
            <p><strong>Año de operación:</strong> ${p.anio}</p>
            <p><strong>Capacidad instalada:</strong> ${p.capacidad}</p>
            <p><strong>Ubicación:</strong> ${p.ciudades}</p>
            <p><strong>Importancia:</strong> ${p.importancia}</p>
            <hr>
            <small>💡 La hidroenergía representa el 70% de la matriz eléctrica colombiana</small>
        `;
    }
}

// ==================== DATOS HIDROENERGÍA DESDE 1965 ====================
const datosHidro = [
    { año: 1965, consumo: 780, shareEnergia: 9.8, shareElectricidad: 11.2 },
    { año: 1970, consumo: 1050, shareEnergia: 11.2, shareElectricidad: 13.5 },
    { año: 1975, consumo: 1180, shareEnergia: 11.9, shareElectricidad: 13.8 },
    { año: 1980, consumo: 1350, shareEnergia: 12.8, shareElectricidad: 14.2 },
    { año: 1985, consumo: 1580, shareEnergia: 13.5, shareElectricidad: 14.8 },
    { año: 1990, consumo: 1850, shareEnergia: 14.5, shareElectricidad: 15.8 },
    { año: 1995, consumo: 2150, shareEnergia: 14.9, shareElectricidad: 16.0 },
    { año: 2000, consumo: 2550, shareEnergia: 15.2, shareElectricidad: 16.2 },
    { año: 2005, consumo: 2850, shareEnergia: 15.5, shareElectricidad: 16.3 },
    { año: 2010, consumo: 3280, shareEnergia: 15.8, shareElectricidad: 16.5 },
    { año: 2015, consumo: 3750, shareEnergia: 16.2, shareElectricidad: 16.8 },
    { año: 2020, consumo: 4150, shareEnergia: 16.0, shareElectricidad: 16.5 },
    { año: 2022, consumo: 4280, shareEnergia: 15.8, shareElectricidad: 16.2 }
];

const datosBarra = {
    hidro: 4280,
    eolica: 2100,
    solar: 1300,
    bio: 680,
    geotermica: 95
};

const datosCapacidad = {
    años: [1965, 1970, 1975, 1980, 1985, 1990, 1995, 2000, 2005, 2010, 2015, 2020, 2022],
    hidro: [210, 320, 380, 480, 540, 620, 690, 780, 870, 980, 1100, 1320, 1410],
    eolica: [0, 0, 0, 0.5, 1, 2, 4, 17, 59, 198, 432, 733, 906],
    solar: [0, 0, 0, 0, 0, 0.1, 0.2, 1, 5, 40, 227, 707, 1053]
};

const datosArea = {
    años: [1965, 1970, 1975, 1980, 1985, 1990, 1995, 2000, 2005, 2010, 2015, 2020, 2022],
    hidro: [780, 1050, 1180, 1350, 1580, 1850, 2150, 2550, 2850, 3280, 3750, 4150, 4280],
    otrasRenovables: [15, 50, 65, 80, 95, 150, 180, 250, 380, 520, 1050, 2050, 2820],
    convencional: [5200, 7800, 8900, 9200, 10100, 11500, 12500, 12800, 13800, 14800, 16200, 15800, 15600]
};

const datosParticipacion = {
    hidro: 16.2,
    eolica: 7.2,
    solar: 4.0,
    otrasRenovables: 2.1,
    convencionales: 70.5
};

// ==================== VARIABLES DE GRÁFICOS ====================
let barChart, pieChart, lineChart, areaChart;

// ==================== INICIALIZACIÓN DE GRÁFICOS ====================
function inicializarGraficos() {
    // Verificar que existan los canvas
    const barCanvas = document.getElementById('barChart');
    const pieCanvas = document.getElementById('pieChart');
    const lineCanvas = document.getElementById('lineChart');
    const areaCanvas = document.getElementById('areaChart');
    
    if (!barCanvas || !pieCanvas || !lineCanvas || !areaCanvas) {
        console.error("No se encontraron los canvas para los gráficos");
        return;
    }
    
    // 1. Gráfico de Barras
    const ctxBar = barCanvas.getContext('2d');
    if (ctxBar) {
        barChart = new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: ['💧 Hidroeléctrica', '🌬️ Eólica', '☀️ Solar', '🔥 Biocombustibles', '🌋 Geotérmica'],
                datasets: [{
                    label: 'Producción mundial (TWh) - 2022',
                    data: [datosBarra.hidro, datosBarra.eolica, datosBarra.solar, datosBarra.bio, datosBarra.geotermica],
                    backgroundColor: ['#1e3a8a', '#22c55e', '#facc15', '#ef4444', '#8b5cf6'],
                    borderRadius: 8,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { position: 'top' },
                    tooltip: { callbacks: { label: (ctx) => `${ctx.raw.toLocaleString()} TWh` } }
                },
                scales: { y: { title: { display: true, text: 'Teravatios-hora (TWh)' } } }
            }
        });
    }

    // 2. Gráfico de Torta
    const ctxPie = pieCanvas.getContext('2d');
    if (ctxPie) {
        pieChart = new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: ['💧 Hidroeléctrica (16.2%)', '🌬️ Eólica (7.2%)', '☀️ Solar (4.0%)', '🔥 Otras (2.1%)', '⚫ Convencionales (70.5%)'],
                datasets: [{
                    data: [datosParticipacion.hidro, datosParticipacion.eolica, datosParticipacion.solar, datosParticipacion.otrasRenovables, datosParticipacion.convencionales],
                    backgroundColor: ['#1e3a8a', '#22c55e', '#facc15', '#ef4444', '#64748b'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'right' } }
            }
        });
    }

    // 3. Gráfico de Líneas
    const ctxLine = lineCanvas.getContext('2d');
    if (ctxLine) {
        lineChart = new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: datosCapacidad.años.map(a => a.toString()),
                datasets: [
                    { 
                        label: '💧 Hidroeléctrica (GW) - Protagonista', 
                        data: datosCapacidad.hidro, 
                        borderColor: '#1e3a8a', 
                        backgroundColor: 'transparent', 
                        tension: 0.3, 
                        borderWidth: 4,
                        pointRadius: 4,
                        pointBackgroundColor: '#1e3a8a'
                    },
                    { label: '🌬️ Eólica (GW)', data: datosCapacidad.eolica, borderColor: '#22c55e', tension: 0.3, borderWidth: 2 },
                    { label: '☀️ Solar (GW)', data: datosCapacidad.solar, borderColor: '#facc15', tension: 0.3, borderWidth: 2 }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${ctx.raw.toLocaleString()} GW` } }
                }
            }
        });
    }

    // 4. Gráfico de Área
    const ctxArea = areaCanvas.getContext('2d');
    if (ctxArea) {
        areaChart = new Chart(ctxArea, {
            type: 'line',
            data: {
                labels: datosArea.años.map(a => a.toString()),
                datasets: [
                    { label: '💧 Hidroenergía (TWh)', data: datosArea.hidro, borderColor: '#1e3a8a', backgroundColor: 'rgba(30, 58, 138, 0.4)', fill: true, tension: 0.3, borderWidth: 3 },
                    { label: '🌱 Otras Renovables (TWh)', data: datosArea.otrasRenovables, borderColor: '#22c55e', backgroundColor: 'rgba(34, 197, 94, 0.3)', fill: true, tension: 0.3 },
                    { label: '⚫ Convencional (TWh)', data: datosArea.convencional, borderColor: '#ef4444', backgroundColor: 'rgba(239, 68, 68, 0.1)', fill: true, tension: 0.3 }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${ctx.raw.toLocaleString()} TWh` } }
                }
            }
        });
    }
    
    console.log("✅ Gráficos inicializados correctamente");
}

// ==================== TABLA DE DATOS ====================
function cargarTabla() {
    const tbody = document.querySelector("#dataTable tbody");
    if (!tbody) {
        console.warn("No se encontró la tabla #dataTable");
        return;
    }
    
    tbody.innerHTML = datosHidro.map(d => `
        <tr>
            <td><strong>${d.año}</strong></td>
            <td class="text-primary fw-bold">${d.consumo.toLocaleString()} TWh</td>
            <td>${d.shareEnergia}%</td>
            <td class="text-primary fw-bold">${d.shareElectricidad}%</td>
            <td>Mundial</td>
        </tr>
    `).join("");
    
    if (tbody.lastElementChild) {
        tbody.lastElementChild.classList.add("table-primary");
    }
    console.log("✅ Tabla cargada con datos desde 1965");
}

// ==================== CALCULADORA ====================
function calcularHidroenergia() {
    const consumoInput = document.getElementById("consumoInput");
    const resultadoDiv = document.getElementById("resultadoCalculadora");
    
    if (!consumoInput || !resultadoDiv) {
        console.error("No se encontraron elementos de la calculadora");
        return;
    }
    
    const consumo = parseFloat(consumoInput.value);
    
    if (isNaN(consumo) || consumo <= 0) {
        resultadoDiv.innerHTML = `<strong>⚠️ Error:</strong> Ingresa un valor válido mayor a 0.`;
        resultadoDiv.className = "alert alert-danger";
        return;
    }
    
    const porcentajeHidroMundial = 16.2;
    const porcentajeHidroColombia = 70;
    const coberturaMundial = (consumo * porcentajeHidroMundial) / 100;
    const coberturaColombia = (consumo * porcentajeHidroColombia) / 100;
    const capacidadHidroGW = 1410;
    
    resultadoDiv.innerHTML = `
        <div class="text-center">
            <h5 class="text-primary">💧 Energía Hidroeléctrica</h5>
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="card p-3 bg-light border-primary">
                        <strong>🌎 Promedio mundial (2022)</strong>
                        <span class="display-6 text-primary">${porcentajeHidroMundial}%</span>
                        <small>de la electricidad mundial es hidroenergía</small>
                        <hr>
                        <strong>💧 Energía hidroeléctrica necesaria:</strong>
                        <span class="h3 text-primary">${coberturaMundial.toFixed(0)} kWh/mes</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-3 bg-success bg-opacity-10 border-success">
                        <strong>🇨🇴 Colombia</strong>
                        <span class="display-6 text-success">${porcentajeHidroColombia}%</span>
                        <small>de la electricidad colombiana es hidroenergía</small>
                        <hr>
                        <strong>💧 Energía hidroeléctrica necesaria:</strong>
                        <span class="h3 text-success">${coberturaColombia.toFixed(0)} kWh/mes</span>
                    </div>
                </div>
            </div>
            <div class="alert alert-primary mt-3">
                💡 <strong>Dato histórico:</strong> Desde 1965, la capacidad hidroeléctrica mundial ha crecido de <strong>210 GW</strong> a <strong>${capacidadHidroGW.toLocaleString()} GW</strong> en 2022.
            </div>
            <div class="alert alert-info mt-2">
                💧 <strong>En Colombia:</strong> Más del 70% de la energía proviene del agua, una de las matrices más limpias de América Latina.
            </div>
        </div>
    `;
    resultadoDiv.className = "alert alert-light border-primary";
}

// ==================== INICIALIZACIÓN ====================
document.addEventListener("DOMContentLoaded", () => {
    console.log("🚀 Inicializando proyecto Hidroenergía...");
    
    // Inicializar componentes
    inicializarGraficos();
    cargarTabla();
    
    // Mostrar sección inicial
    showSection('historia');
    
    console.log("✅ Proyecto Hidroenergía listo - Datos desde 1965");
});